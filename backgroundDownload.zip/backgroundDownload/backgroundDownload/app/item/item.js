"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Item = (function () {
    function Item() {
    }
    return Item;
}());
exports.Item = Item;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIml0ZW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUFBO0lBSUEsQ0FBQztJQUFELFdBQUM7QUFBRCxDQUFDLEFBSkQsSUFJQztBQUpZLG9CQUFJIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIEl0ZW0ge1xuICAgIGlkOiBudW1iZXI7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIHJvbGU6IHN0cmluZztcbn1cbiJdfQ==